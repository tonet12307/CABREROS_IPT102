package com.example.cabreros_mvvm;

public class FoodItems {

    private final String foodName;
    private final String foodPrice;

    public FoodItems(String foodName, String foodPrice) {
        this.foodName = foodName;
        this.foodPrice = foodPrice;
    }

    public String getFoodName() {
        return foodName;
    }

    public String getFoodPrice() {
        return foodPrice;
    }
}
