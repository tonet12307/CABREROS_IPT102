package com.example.cabreros_mvvm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

class FoodAdapter extends RecyclerView.Adapter<FoodViewHolder> {

    Context context;
    List<FoodItems> items;

    public FoodAdapter(MainActivity context, List<FoodItems> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.items, parent, false);
        return new FoodViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        FoodItems item = items.get(position);

        holder.foodName.setText(item.getFoodName());
        holder.foodPrice.setText(item.getFoodPrice());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
